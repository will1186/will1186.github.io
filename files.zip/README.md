# will1186.github.io

Personal portfolio and blog. Built with plain HTML/CSS — no frameworks, no build step.

## Deploy to GitHub Pages

1. Create a repo named `will1186.github.io` on GitHub
2. Clone it locally:
   ```bash
   git clone https://github.com/will1186/will1186.github.io.git
   cd will1186.github.io
   ```
3. Copy all files from this folder into the repo
4. Push:
   ```bash
   git add .
   git commit -m "initial site"
   git push origin main
   ```
5. Your site will be live at `https://will1186.github.io` within a few minutes

## File Structure

```
├── index.html              # Home page
├── projects.html           # Projects listing
├── blog.html               # Blog listing
├── style.css               # Shared stylesheet
├── projects/
│   └── apt45-analysis.html # Project detail (template)
├── blog/
│   └── first-post.html     # Blog post (template)
└── README.md
```

## Adding Content

**New project:**
1. Copy `projects/apt45-analysis.html` → `projects/your-project.html`
2. Update the title, meta, and body content
3. Add a card linking to it in `projects.html`

**New blog post:**
1. Copy `blog/first-post.html` → `blog/your-post.html`
2. Update the title, date, and body content
3. Add an entry linking to it in `blog.html`

## Customization

- Colors, fonts, spacing: edit CSS variables at the top of `style.css`
- LinkedIn URL: update the `href` in nav across all pages
- Bio text: edit the `.bio` paragraph in `index.html`
